# `Queuing System in JS`
![](https://static.javatpoint.com/ds/images/ds-types-of-queue2.png)
